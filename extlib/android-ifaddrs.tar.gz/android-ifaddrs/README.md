android-ifaddrs
===============

An implementation of getifaddrs() for Android, since the NDK does not natively support it.

Works just like you would expect on regular Linux. License information is present in each file (BSD license).
